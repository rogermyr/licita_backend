# app/crud/licitacao_acompanhamento.py

from typing import List, Optional
from sqlalchemy.orm import Session
from db.models.licitacao import LicitacaoDBModel
from models import Usuario

# Assumindo que você tem um modelo Pydantic para o Read/Response
from schemas.licitacao import LicitacaoAcompanhamentoRead # Exemplo

def get_acompanhamentos_by_user(
    db: Session, 
    user_id: int, 
    skip: int = 0, 
    limit: int = 100
) -> List[LicitacaoDBModel]:
    """
    Busca todas as licitações em acompanhamento para um usuário específico, com paginação.
    Princípio: Separação da Lógica de Negócio (aqui é pura lógica de dados).
    """
    return (
        db.query(LicitacaoDBModel)
        .filter(LicitacaoDBModel.user_id == user_id)
        .offset(skip)
        .limit(limit)
        .all()
    )

# Outras funções como create, update, delete iriam aqui.