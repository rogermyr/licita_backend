# app/crud/acompanhamento_logic.py

from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
# Importamos nullslast para garantir que nulos vão para o final da ordenação
from sqlalchemy import desc, asc, cast, DateTime, nullslast 
from typing import List, Optional, Any
import logging

from models import Acompanhamento, LicitacaoItem, Usuario, LicitacaoRaw 

logger = logging.getLogger(__name__)

# --- CONFIGURAÇÃO CHAVE PARA ORDENAÇÃO JSON ---
# Usamos o campo de encerramento da proposta conforme solicitado.
JSON_DATE_FIELD = 'dataEncerramentoProposta' 

def get_json_date_order_expression(field_name: str):
    """Retorna a expressão SQLAlchemy para ordenar pelo campo JSON, tratando-o como DateTime."""
    # Extrai o texto do campo JSON e converte para DateTime para ordenação correta.
    return cast(
        LicitacaoRaw.conteudo_json[field_name].astext, 
        DateTime
    )

# --- Mapeamento de Colunas para Ordenação ---
ALLOWED_ORDER_FIELDS = {
    # Mapeia o parâmetro 'data_encerramento' para a expressão de extração JSON
    "data_encerramento": get_json_date_order_expression(JSON_DATE_FIELD),
    
    "data_acompanhamento": Acompanhamento.data_acompanhamento,
    "valor_estimado": LicitacaoItem.valor_unitario, 
}

# --- LÓGICA DE CRIAÇÃO/EXCLUSÃO (TOGGLE) ---
def toggle_acompanhamento(db: Session, user_id: int, item_id: int, should_acompanhar: bool) -> bool:
    """Marca ou desmarca um item de licitação para acompanhamento pelo usuário."""
    
    existing = db.query(Acompanhamento).filter(
        Acompanhamento.user_id == user_id,
        Acompanhamento.item_id == item_id
    ).first()

    if should_acompanhar:
        if existing:
            return True 
        
        try:
            if not db.query(LicitacaoItem).filter(LicitacaoItem.id == item_id).first():
                logger.error(f"Tentativa de acompanhar Item ID {item_id} que não existe.")
                return False

            novo_acompanhamento = Acompanhamento(
                user_id=user_id,
                item_id=item_id
            )
            db.add(novo_acompanhamento)
            db.commit()
            return True
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao marcar item {item_id} para acompanhamento: {e}")
            return False
            
    else: # Desmarcar
        if existing:
            db.delete(existing)
            db.commit()
            return True
        else:
            return True 


# --- LÓGICA DE LEITURA COM DUPLO JOIN, ORDENAÇÃO E EAGER LOADING ---

def get_acompanhamentos_by_user(
    db: Session, 
    user_id: int, 
    skip: int = 0, 
    limit: int = 100,
    sort_by: str = "data_encerramento",
    order: str = "asc"
) -> List[Acompanhamento]:
    """
    Busca os registros de acompanhamento para um usuário, permitindo ordenação
    pela data extraída do conteudo_json da LicitacaoRaw e utilizando Eager Loading.
    """
    
    # 1. Inicia a query com JOINs
    query = (
        db.query(Acompanhamento)
        .join(LicitacaoItem, Acompanhamento.item_id == LicitacaoItem.id)
        # JOIN 2: Usando a propriedade de relacionamento 'licitacao_raw'
        .join(LicitacaoItem.licitacao_raw) 
        .filter(Acompanhamento.user_id == user_id)
        # Eager Loading para carregar LicitacaoItem e LicitacaoRaw em uma única consulta (evita Lazy Load falho)
        .options(
             joinedload(Acompanhamento.item_detalhes).joinedload(LicitacaoItem.licitacao_raw)
        )
    )

    # 2. DETERMINA O CAMPO E ORDEM DE ORDENAÇÃO
    order_expression = ALLOWED_ORDER_FIELDS.get(sort_by)
    
    if order_expression is not None:
        
        order_column = order_expression

        if order.lower() == 'desc':
            # Datas mais recentes no topo, Nulos (sem data de encerramento) no final
            query = query.order_by(nullslast(desc(order_column)))
        elif order.lower() == 'asc':
            # Datas mais antigas/próximas no topo, Nulos (sem data de encerramento) no final
            query = query.order_by(nullslast(asc(order_column)))
        
        # Fallback de desempate
        query = query.order_by(Acompanhamento.id)
    else:
        # Fallback de ordenação se o campo for inválido
        query = query.order_by(desc(Acompanhamento.data_acompanhamento))
        
    # 3. APLICA PAGINAÇÃO E EXECUTA
    return (
        query
        .offset(skip)
        .limit(limit)
        .all()
    )

def check_item_is_acompanhado(db: Session, user_id: int, item_id: int) -> bool:
    """Verifica rapidamente se um item está em acompanhamento."""
    return db.query(Acompanhamento).filter(
        Acompanhamento.user_id == user_id,
        Acompanhamento.item_id == item_id
    ).first() is not None