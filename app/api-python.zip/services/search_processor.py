# app/services/search_processor.py
from datetime import datetime
from typing import List, Dict, Any, Tuple
from sqlalchemy.orm import Session
from schemas.schemas import MatchResponse # # MODIFICADO: Caminho absoluto para evitar erros de import
import unidecode 
import logging

logger = logging.getLogger(__name__)

# --- UTILITÁRIOS ---

def remover_acentos(text_val: str) -> str:
    """Normaliza texto para comparação de precisão (remoção de acentos e lower case)."""
    if not text_val: return ""
    return unidecode.unidecode(text_val).lower()

def _gerar_link_pncp(identificador: str) -> str:
    """
    Transforma o identificador (ex: 91987669000174-1-000604/2025) 
    no link oficial do portal de editais.
    """
    try:
        # Padrão PNCP: CNPJ-1-SEQUENCIAL/ANO
        partes = identificador.replace('-', '/').split('/')
        cnpj = partes[0]
        seq = partes[2]
        ano = partes[3]
        return f"https://pncp.gov.br/app/editais/{cnpj}/{ano}/{seq}"
    except Exception:
        return "https://pncp.gov.br/app/editais/"

# --- PROCESSAMENTO PRINCIPAL ---

def _format_silver_row_to_match(
    row: Any, 
    chaves_normalizadas_map: List[Tuple[str, str]]
) -> Dict[str, Any] | None:
    """
    Transforma uma linha da camada SILVER em um dicionário compatível com MatchResponse.
    PÓS-FILTRAGEM: Valida se o termo chave realmente está na descrição (Precisão).
    """
    
    # 1. VALIDAÇÃO DE PRECISÃO (Substring Match)
    # Garante que o termo chave literal do perfil existe na descrição do item
    desc_norm = remover_acentos(row.descricao)
    termos_encontrados = [
        orig for orig, norm in chaves_normalizadas_map 
        if norm in desc_norm
    ]
    
    if not termos_encontrados:
        # Se for um falso positivo do FTS (ex: buscou 'carro' e achou 'carroça'), descarta.
        return None 
        
    # 2. MONTAGEM DO LOCAL
    local = f"{row.municipio_nome}/{row.uf_sigla}" if row.municipio_nome else row.uf_sigla

    # 3. RETORNO DOS DADOS (MAREAMENTO SILVER -> SCHEMA)
    return {
        "id": row.item_id,
        "perfil_cliente": "Múltiplos Perfis",
        "palavra_encontrada": row.descricao,
        "termo_chave": ", ".join(termos_encontrados),
        "objeto_licitacao": row.objeto,
        
        # // MODIFICADO: Mapeamento de Valores com Fallback para zero
        "valor_unitario": float(row.valor_unitario or 0),
        "quantidade": float(row.quantidade or 0), 
        
        # // CRÍTICO: 'valor_total_item' vem do cálculo COALESCE no search_logic.py
        "valor_total_item": float(row.valor_total_item or 0),
        
        # 'valor_estimado' mantido por compatibilidade com versões anteriores do Schema
        "valor_estimado": float(row.valor_total_item or 0), 
        
        "link_pncp": _gerar_link_pncp(row.licitacao_identificador),
        "data_match": row.data_publicacao,
        "data_encerramento": row.data_encerramento,
        "local": local,
        "link_origem_bruto": row.link_origem_bruto,
        # Garantimos que modalidade_codigo seja String para o Pydantic
        "modalidade_codigo": str(row.modalidade_nome) 
    }


def process_search_results(db: Session, perfis: List[Any], resultados_brutos: List[Any]) -> List[MatchResponse]:
    """
    Orquestra a transformação de resultados SQL para a lista final de Matches.
    """
    lista_final: List[MatchResponse] = []
    ids_vistos = set()

    # Prepara o mapa de termos chaves uma única vez para performance
    chaves_brutas = []
    for p in perfis:
        kw = p.palavras_chave or ""
        for k in kw.split(","):
            if k.strip(): chaves_brutas.append(k.strip())
    
    # Remove duplicatas e normaliza
    chaves_map = [(c, remover_acentos(c)) for c in set(chaves_brutas)]
    
    logger.info(f"🚀 Silver Processor: Formatando {len(resultados_brutos)} itens.")

    for row in resultados_brutos:
        # Evita duplicidade se o mesmo item for retornado em múltiplas páginas/joins
        if row.item_id in ids_vistos: continue

        try:
            # Chama a função de formatação
            dados = _format_silver_row_to_match(row, chaves_map)
            
            if dados:
                # Converte o dicionário no objeto Pydantic (MatchResponse)
                lista_final.append(MatchResponse(**dados))
                ids_vistos.add(row.item_id)
                
        except Exception as e:
            # Loga o erro de validação para debug (ajuda a pegar campos faltando no Schema)
            logger.error(f"❌ Erro ao formatar item {getattr(row, 'item_id', 'N/A')}: {e}")
            continue
            
    return lista_final