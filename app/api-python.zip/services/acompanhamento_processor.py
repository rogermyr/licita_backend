# app/services/acompanhamento_processor.py (Conteúdo COMPLETO e CORRIGIDO)

from typing import List, Dict, Any
from datetime import datetime, timedelta
import logging

# Importe o modelo ORM de Relação que será recebido
from models import Acompanhamento
# Importe o schema de resposta
from schemas.schemas import ItemAcompanhadoResponse

# Importe a função de formatação de dados brutos
# Assumimos que a lógica de formatação de dados brutos reside no search_processor.
# Para evitar dependências circulares ou duplicação, vamos redefinir a função essencial aqui.

logger = logging.getLogger(__name__)

# --- Replicando a lógica de formatação essencial ---
# Nota: Esta função é uma versão simplificada da _extract_and_format_data do search_processor,
# pois não precisamos de filtros FTS ou validação de perfis.

def remover_acentos(text: str) -> str:
    """Função utilitária (copiada de db.utils ou search_logic)"""
    import unidecode 
    return unidecode.unidecode(text).lower()


def _format_raw_item(row: Any, data_acompanhamento: datetime) -> Dict[str, Any] | None:
    """
    Extrai e formata dados de um objeto LicitacaoItem relacionado
    para o formato ItemAcompanhadoResponse.
    """
    
    # Mapeamento do ORM: Acompanhamento.item_detalhes -> LicitacaoItem -> LicitacaoRaw
    item_db = row 
    if not item_db or not item_db.licitacao_raw:
        return None 
        
    raw_data = item_db.licitacao_raw
    dados_json = raw_data.conteudo_json 
    
    item_id = item_db.id
    
    # 1. VALIDAÇÃO JSON
    if not isinstance(dados_json, dict):
        logger.warning(f"DESCARTE ID {item_id}: Conteúdo JSON não é um dicionário.")
        return None 

    # 2. DATAS
    dt_fim = None 
    data_fim_proposta = dados_json.get('dataEncerramentoProposta')
    if data_fim_proposta:
        try: 
            dt_fim = datetime.fromisoformat(data_fim_proposta.replace('Z', '+00:00'))
        except Exception: 
            dt_fim = None
    
    # 3. CONSTRUIR LINKS E LOCAL
    cnpj = dados_json.get('orgaoEntidade', {}).get('cnpj', '00000000000000')
    ano = dados_json.get('anoCompra', '0000')
    seq = dados_json.get('sequencialCompra', '0')
    link = f"https://pncp.gov.br/app/editais/{cnpj}/{ano}/{seq}" 
    
    local = dados_json.get('unidadeOrgao', {}).get('ufSigla', 'BR')
    municipio_nome = dados_json.get('unidadeOrgao', {}).get('municipioNome')
    
    if municipio_nome:
        local = f"{municipio_nome}/{local}"

    # 4. RETORNO DE DADOS FORMATADOS
    logger.debug(f"SUCESSO ID {item_id}: Item de acompanhamento formatado.")
    return {
        "id": item_id,
        "perfil_cliente": "Acompanhado Manualmente",
        "palavra_encontrada": item_db.descricao,
        "termo_chave": "N/A", 
        "objeto_licitacao": raw_data.objeto,
        
        # Ajuste Crítico: valor_estimado é o valor unitário na tabela MatchResponse.
        # Adicionamos o valor_unitario para garantir que o frontend o encontre.
        "valor_estimado": item_db.valor_unitario,
        "quantidade": item_db.quantidade, 
        "valor_unitario": item_db.valor_unitario, # NOVO: Adicionado para satisfazer o frontend
        
        "link_pncp": link,
        "fonte_dados": raw_data.nome_sistema_origem if hasattr(raw_data, 'nome_sistema_origem') else 'OUTRO_SISTEMA', 
        "data_match": raw_data.data_publicacao,
        "data_encerramento": dt_fim,
        "local": local,
        "link_origem_bruto": dados_json.get('linkSistemaOrigem'),
        "modalidade_codigo": raw_data.codigo_modalidade,
        
        # CAMPO ESPECÍFICO DE ACOMPANHAMENTO
        "data_acompanhamento": data_acompanhamento
    }


def process_acompanhamento_list(acompanhamentos_brutos: List[Acompanhamento]) -> List[ItemAcompanhadoResponse]:
    """
    Processa uma lista de objetos Acompanhamento ORM para o formato Pydantic.
    """
    lista_final: List[ItemAcompanhadoResponse] = []
    
    logger.info(f"PROCESSAMENTO ACOMPANHAMENTO: Iniciando processamento de {len(acompanhamentos_brutos)} registros.")

    for acompanhamento_record in acompanhamentos_brutos:
        # Acessa os detalhes do item através da relação ORM
        item_detalhes = acompanhamento_record.item_detalhes 
        
        if not item_detalhes:
            logger.warning(f"Item ID {acompanhamento_record.item_id} não possui detalhes de item (possivelmente deletado). Ignorando.")
            continue

        try:
            dados_formatados = _format_raw_item(
                item_detalhes, 
                acompanhamento_record.data_acompanhamento
            )
        except Exception as e:
            logger.error(f"PROCESSAMENTO ACOMPANHAMENTO: ERRO INESPERADO ao processar item ID {acompanhamento_record.item_id}: {e}", exc_info=True)
            continue
        
        if dados_formatados:
            try:
                # Serializa o dicionário formatado para o Pydantic
                lista_final.append(ItemAcompanhadoResponse(**dados_formatados))
            except Exception as e:
                 logger.error(f"Erro ao validar MatchResponse para item {acompanhamento_record.item_id}: {e}")
            
    logger.info(f"PROCESSAMENTO ACOMPANHAMENTO: {len(lista_final)} itens formatados e prontos para envio.")
    return lista_final