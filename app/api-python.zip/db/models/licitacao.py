from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey 
from sqlalchemy.orm import declarative_base
from datetime import datetime

# Importe sua base declarativa (pode estar em app/db/base.py ou app/db/session.py)
# Substitua 'Base' pela sua declaração real, se for diferente.
from db.base import Base # ASSUMIDO

class LicitacaoDBModel(Base):
    """
    Modelo ORM para a tabela de licitações acompanhadas.
    Espelha os campos da Entidade de Domínio, mas com tipos de DB.
    """
    __tablename__ = "licitacoes_acompanhamento"

    # Chave Primária Interna
    id = Column(Integer, primary_key=True, index=True) 
    
    # Identificação Externa (ID do Match, deve ser único para prevenção de duplicação)
    id_externo = Column(String, unique=True, index=True, nullable=False) 
    user_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False, index=True) 

    # Dados Relevantes
    fonte = Column(String(50), nullable=False)
    objeto = Column(String, nullable=False)
    status_acompanhamento = Column(String(50), default="EM_ACOMPANHAMENTO", nullable=False)
    
    # Prazos e Valores
    data_encerramento = Column(DateTime, nullable=True)
    valor_estimado = Column(Float, nullable=True)
    
    # Links e Anotações
    link_pncp = Column(String, nullable=True)
    anotacoes = Column(String, nullable=True)
    
    # Metadata
    data_cadastro = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f"<Licitacao(id={self.id}, objeto='{self.objeto[:30]}')>"