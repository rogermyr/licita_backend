# app/db/repositories/licitacao_repo.py (Revisado e Completo)

from sqlalchemy.orm import Session
from sqlalchemy.future import select
from typing import Optional, List

# Dependências do Core
from core.ports.repositorio_licitacoes import RepositorioLicitacoes
from core.domain.licitacao import Licitacao
# Dependência do Modelo ORM
from db.models.licitacao import LicitacaoDBModel 
from db.mappers import map_db_to_domain, map_domain_to_db 

class LicitacaoRepositorioSQLAlchemy(RepositorioLicitacoes):
    """Implementação completa do Repositório usando SQLAlchemy."""
    def __init__(self, db_session: Session):
        self.db_session = db_session

    def salvar(self, licitacao: Licitacao) -> Licitacao:
        # Garante que o user_id é repassado ao modelo DB
        db_model = map_domain_to_db(licitacao) 
        
        # O user_id JÁ DEVE estar no db_model aqui
        
        self.db_session.add(db_model)
        self.db_session.flush() # Obtém o ID interno
        self.db_session.commit()
        
        # O Pydantic PRECISA ver a Entidade DOMÍNIO completa.
        # 1. Atribui o ID interno
        licitacao.id_interno = db_model.id
        
        # 2. SE FOR NECESSÁRIO, GARANTA QUE TODOS OS DADOS ESTÃO PRESENTES ANTES DE RETORNAR
        # Neste caso, a Entidade `licitacao` passada para a função já deveria ter o user_id. 
        
        return licitacao # Retorna a Entidade que será serializada

    # MÉTODO NECESSÁRIO PARA O CASO DE USO (checa se existe)
    def existe_por_id_externo(self, id_externo: str) -> bool:
        # A implementação original do caso de uso usa 'existe_por_id_externo'
        stmt = select(LicitacaoDBModel).filter(LicitacaoDBModel.id_externo == id_externo)
        # Verifica se pelo menos um registro existe
        result = self.db_session.execute(stmt).scalar_one_or_none()
        return result is not None

    # MÉTODO FALTANTE QUE CAUSOU O ERRO TypeError
    def buscar_por_id_externo(self, id_externo: str) -> Optional[Licitacao]: # IMPLEMENTADO
        stmt = select(LicitacaoDBModel).filter(LicitacaoDBModel.id_externo == id_externo)
        db_model = self.db_session.execute(stmt).scalar_one_or_none()
        
        if db_model:
            return map_db_to_domain(db_model)
        return None

    # OUTRO MÉTODO ABSTRATO (Garantindo a implementação completa do contrato)
    def buscar_todos(self) -> List[Licitacao]: 
        # Implementação para listar todas as licitações acompanhadas
        stmt = select(LicitacaoDBModel)
        db_models = self.db_session.execute(stmt).scalars().all()
        return [map_db_to_domain(m) for m in db_models]