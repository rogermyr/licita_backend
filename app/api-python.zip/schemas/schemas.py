# app/schemas/schemas.py
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any 
from datetime import datetime, date

# --- 1. SCHEMAS DE USUÁRIO ---

class UserCreate(BaseModel):
    username: str # Será mapeado para o email no banco
    password: str
    nome_completo: str
    telefone: str
    cpf: str
    cargo: str

class UserResponse(BaseModel):
    id: int
    username: str
    nome_completo: Optional[str] = None
    telefone: Optional[str] = None
    cpf: Optional[str] = None
    cargo: Optional[str] = None
    data_cadastro: Optional[datetime] = None 
    
    # Pydantic V2 usa ConfigDict para conversão de objetos ORM (SQLAlchemy)
    model_config = ConfigDict(from_attributes=True)


# --- 2. SCHEMAS DE PERFIS (CONFIGURAÇÃO DE BUSCA) ---

class PerfilSchema(BaseModel):
    nome_perfil: str
    palavras_chave: str
    palavras_negativas: Optional[str] = None 

class PerfilResponse(PerfilSchema):
    id: int
    model_config = ConfigDict(from_attributes=True)


# --- 3. SCHEMAS DE VARREDURA (REQUEST DO FRONTEND) ---

class VarreduraRequest(BaseModel):
    """Filtros enviados pelo Dashboard React."""
    perfil_ids: List[int]
    filtro_uf: Optional[List[str]] = None
    filtro_modalidade: Optional[List[int]] = None # Códigos das modalidades (1, 6, 8, etc)

    # Paginação Tradicional
    limit: int = Field(default=50, gt=0, le=100, description="Máximo 100 itens por página.")
    offset: int = Field(default=0, ge=0)
    
    # Keyset Pagination (Cursor para alta performance AWS)
    last_valor_total: Optional[float] = Field(None, description="Cursor: Valor do último item.")
    last_item_id: Optional[int] = Field(None, description="Cursor: ID do último item.")


# --- 4. SCHEMAS DE MATCH (RESPOSTA DA LICITAÇÃO) ---

class MatchResponse(BaseModel):
    id: int
    perfil_cliente: str
    palavra_encontrada: str 
    termo_chave: str 
    objeto_licitacao: str
    valor_estimado: Optional[float] = None
    quantidade: Optional[float] = None
    valor_unitario: Optional[float] = None 
    # // NOVO: Adicione este campo para o Pydantic não filtrá-lo
    valor_total_item: Optional[float] = None 
    
    link_pncp: str
    data_match: datetime
    local: str
    modalidade_codigo: Optional[str] = None
    data_encerramento: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


# --- 5. SCHEMAS DE PAGINAÇÃO (METADADOS) ---

class CursorInfo(BaseModel):
    """Metadados para o React gerenciar o 'Carregar Mais'."""
    next_last_valor_total: Optional[float] = None
    next_last_item_id: Optional[int] = None

class VarreduraPaginadaResponse(BaseModel):
    """Container final da resposta da busca."""
    total_items: int
    limit: int
    offset: int
    resultados: List[MatchResponse]
    cursor: Optional[CursorInfo] = None 


# --- 6. SCHEMAS DE ACOMPANHAMENTO (TRACKING) ---

class AcompanhamentoAction(BaseModel):
    item_id: int
    acompanhar: bool = True

class ItemAcompanhadoResponse(MatchResponse):
    """MatchResponse + metadados de controle do usuário."""
    data_acompanhamento: datetime
    model_config = ConfigDict(from_attributes=True)


# --- 7. SISTEMAS (MANTIDO POR LEGADO) ---

class SistemaResponse(BaseModel): 
    nome: str
    model_config = ConfigDict(from_attributes=True)